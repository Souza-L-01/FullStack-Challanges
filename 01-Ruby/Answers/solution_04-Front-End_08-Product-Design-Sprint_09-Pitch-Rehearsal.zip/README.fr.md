## Répétition du pitch (30 min)

C'est le moment de préparer ton pitch ! Dans quelques minutes, tu présenteras le prototype de ton produit devant la classe. Voici quelques conseils :

- **Mets-toi dans la peau d'un utilisateur** : C'est le moyen le plus efficace de présenter ton produit. Commence par exposer ton problème en tant qu'utilisateur et explique comment l'application permet de le résoudre.
- **Fais court** : 4 minutes devraient suffire à présenter ton parcours utilisateur. 
- **Évite les termes techniques** : Ce qui nous intéresse, c'est l'expérience utilisateur. Alors évite les termes techniques et n'aborde pas les fonctionnalités futures.
- **Entraîne-toi, encore et encore** : Plus tu t'entraîneras, plus tu seras à l'aise et plus ta présentation sera claire. 

Et surtout : **Sois fier de toi**. Souviens-toi de ton idée de départ et regarde tout le travail accompli pour en arriver à ton prototype.

Bonne chance !
