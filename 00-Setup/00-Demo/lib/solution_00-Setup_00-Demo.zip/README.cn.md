## 背景和目标

欢迎来到Kitt! 接下来老师会演示如何完成练习。

## 详细说明

我们的目标是要实现 `circle_area` 方法， 取 **1个** 参数,
`radius`, 然后返回这个给定半径的圆的面积。提示一下，求圆的面积的公式：

![圆的面积](https://raw.githubusercontent.com/lewagon/fullstack-images/master/ruby/area-circle.svg?sanitize=true)

现在请打开 `lib/demo.rb` 文件并实现它吧!

`rake` 命令会检查 **4 个测试**。请确保所有的都是绿色的!
