## Contexte et objectifs

Bienvenue sur Kitt ! La ou le prof va maintenant te montrer comment réaliser un exercice.

## Spécifications

L’objectif est de mettre en œuvre une méthode `circle_area` qui prend **un** paramètre,
`radius`, et renvoie l’aire du cercle avec ce rayon. Pour rappel,
voici la formule :

![Area Circle](https://raw.githubusercontent.com/lewagon/fullstack-images/master/ruby/area-circle.svg?sanitize=true)

Ouvre le fichier `lib/demo.rb` et installe-le !

Il y a **4 tests** qui seront vérifiés par la commande `rake`. Assure-toi qu’ils soient tous en vert !
