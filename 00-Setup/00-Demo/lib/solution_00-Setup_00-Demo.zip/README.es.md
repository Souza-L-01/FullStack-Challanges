## Contexto y Objetivos

¡Bienvenido/a a Kitt!! Tu profesor/a te mostrará cómo hacer un ejercicio.

## Especificaciones

El objetivo es implementar el método `circle_area` el cual toma **un** parámetro, `radius`, y devuelve el área de un círculo con respecto a dicho radio.
Si no sabes como hacer el cálculo, acá está la fórmula:
![Área de un círculo](https://raw.githubusercontent.com/lewagon/fullstack-images/master/ruby/area-circle.svg?sanitize=true)


Abre el archivo `lib/demo.rb` e instálalo!

Existen **4 pruebas** que serán revisadas por el comando `rake`. ¡Asegúrate de que todas estén en verde!

